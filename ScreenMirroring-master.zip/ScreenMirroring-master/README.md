# ScreenMirroring: 
A Screen mirroring android application for mirroring your phone screen on a secondary device.
